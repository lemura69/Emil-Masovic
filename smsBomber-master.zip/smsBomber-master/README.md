# smsBomber
Linux Bash script
Bomb any SMS number with messages using existing E-Mail account.
